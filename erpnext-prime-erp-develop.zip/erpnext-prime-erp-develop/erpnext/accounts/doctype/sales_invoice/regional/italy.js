{% include "erpnext/regional/italy/sales_invoice.js" %}

erpnext.setup_e_invoice_button('Sales Invoice')