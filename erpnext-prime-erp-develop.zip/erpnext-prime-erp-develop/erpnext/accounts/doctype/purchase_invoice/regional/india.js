{% include "erpnext/regional/india/taxes.js" %}

erpnext.setup_auto_gst_taxation('Purchase Invoice');
