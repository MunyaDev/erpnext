# -*- coding: utf-8 -*-
# Copyright (c) 2017, sathishpy@gmail.com and Contributors
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest

class TestBankStatementTransactionEntry(unittest.TestCase):
	pass
